﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beginning_CSharp
{
    class TRex : Dinosaur
    {
        public void Growl()
        {
            Roar();
        }
    }
}
