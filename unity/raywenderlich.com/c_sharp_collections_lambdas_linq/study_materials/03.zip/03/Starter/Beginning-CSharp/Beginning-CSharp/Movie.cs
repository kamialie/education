﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beginning_CSharp
{
    class Movie
    {
        public string Title { get; set; }
        public int ReleaseDate { get; set; }
        public int Runtime { get; set; }
    }
}
